<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Restaurant &amp; Coffee Shop</title>
		<link rel="stylesheet" href="assets/css/home.css">
		<link rel="stylesheet" href="assets/css/all.css">
		<script src="./assets/js/jquery.min.js"></script>
		<script src="./assets/js/script.js"></script>
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
		<link href="https://fonts.googleapis.com/css2?family=Overpass:ital,wght@1,700&amp;display=swap" rel="stylesheet">
		<!--font google-->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
		<link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500&amp;family=Dancing+Script:wght@400;500;600;700&amp;family=Lobster&amp;family=Lobster+Two&amp;family=Marck+Script&amp;family=Reggae+One&amp;family=STIX+Two+Text:ital,wght@1,500&amp;family=Satisfy&amp;family=Yellowtail&amp;display=swap" rel="stylesheet">
	</head>
	<body>
		<header>
			<!--video back ground-->
			<div class="index-video-wrapper">
				<video autoplay="" muted="" nocontrols="" loop="" poster="assets/images/poster.jpg" id="index-video">
					<source src="assets/videos/video.mp4" type="video/mp4">
				</video>
			</div>
			<a href="#"><img src="assets/images/Logo-img.png" width="50px" alt=""></a>
			<nav>
				<ul>
					<li><a href="home.html">Home</a></li>
					<li><a href="#menus-area">Menu</a></li>
					<li><a href="#About us">About</a></li>
					<li><a href="#gallary">Gallary</a></li>
					<li><a href="#reviews">Reviews</a></li>
					<li><a href="#contact us">Contact</a></li>
				</ul>
				<div class="Cart">
					<i class="fa fa-cart-shopping"></i><span id="totalPrice">0.00</span><button id="resetcart">Reset</button>
				</div>
			</nav>
			<div class="Home">
				<span class="copyright">™</span>
				<h1 style="font-family: 'Overpass', sans-serif;color: #ffffff;margin-bottom: 35px;font-size: 90px;">Fast Food</h1>
				<h1 style="font-family: 'Overpass', sans-serif;color: #ffffff;">Best Quality food</h1>
				<h1 style="font-family: 'Overpass', sans-serif;color: #ffffff;font-size: 25px;margin-top: 14px;">2001</h1>
			</div>
		</header>
		<section id="menus-area" class="menus-area" style="background-image: url('assets/images/background.jpg');">
			<div class="container">
				<div class="section-title">
					<h4>our menu</h4>
					<p>We wish you a happy time.</p>
				</div>
				<p id="demo"></p>
				<div class="menus">
					<div class="menu-items">
						<div class="title">breakfast</div>
						<div class="single-menu">
							<span>$30</span>
							<img src="assets/images/food/food1.jpg" alt="">
							<h4>Mix Cheese Pasta</h4>
							<p>Penne pasta white sauce, mozzarella ball, parmesan, cheddar
							</p>
							<button class="btn" price="30" food="food title 1" style="border-radius: 10px; background: none; width: 100px; height: 30px; border: 2px solid red; color: red;">order
							now</button>
						</div>
						<div class="single-menu">
							<span>$50</span>
							<img src="assets/images/food/food2.jpg" alt="">
							<h4>Vegetables Yaki Soba Noodles
							</h4>
							<p>vegetables dish consist of Noodles, vegetables and soy sauce
							</p>
							<button class="btn" price="50" food="food title 2" style="border-radius: 10px; background: none; width: 100px; height: 30px; border: 2px solid red; color: red;">order
							now</button>
						</div>
					</div>
					<div class="menu-items">
						<div class="title">lunch</div>
						<div class="single-menu">
							<span>$40</span>
							<img src="assets/images/food/food3.jpg" alt="">
							<h4>Tom Yum Soup</h4>
							<p>Tom yum paste dish, crab, shrimp, squid, scallions 
								and leamon
							</p>
							<button class="btn" price="40" food="food title 3" style="border-radius: 10px; background: none; width: 100px; height: 30px; border: 2px solid red; color: red;">order
							now</button>
						</div>
						<div class="single-menu">
							<span>$45</span>
							<img src="assets/images/food/food4.jpg" alt="">
							<h4>Beef Yaki Soba Noodles</h4>
							<p>Beef Yaki Dish consist of Noodles, beef, vegetables and soy sauce
							</p>
							<button class="btn" price="45" food="food title 4" style="border-radius: 10px; background: none; width: 100px; height: 30px; border: 2px solid red; color: red;">order
							now</button>
						</div>
					</div>
					<div class="menu-items">
						<div class="title">dinner</div>
						<div class="single-menu">
							<span>$50</span>
							<img src="assets/images/food/food5.jpg" alt="">
							<h4>Volcano Roll</h4>
							<p>volcano Roll Dish Shrimp tempura, smoked salmon, avocado and cheese
							</p>
							<button class="btn" price="50" food="food title 5" style="border-radius: 10px; background: none; width: 100px; height: 30px; border: 2px solid red; color: red;">order
							now</button>
						</div>
						<div class="single-menu">
							<span>$50</span>
							<img src="assets/images/food/food6.jpg" alt="">
							<h4>Chicken Yaki Soba Noodles</h4>
							<p>Chicken Yaki dish Noodles, chicken, vegetables and soy sauce
							</p>
							<button class="btn" price="50" food="food title 6" style="border-radius: 10px; background: none; width: 100px; height: 30px; border: 2px solid red; color: red;">order
							now</button>
						</div>
					</div>
				</div>
				<script>
					// load cart from local storage
					var cart = JSON.parse(localStorage.getItem("cart")) || [];
					
					// update total price
					var totalPriceElement = document.getElementById("totalPrice");
					var total = 0;
					cart.forEach(function (item) {
					  total += item.totalPrice;
					});
					totalPriceElement.textContent = total.toFixed(2);
					//php
				</script>
			</div>
		</section>
		<section id="About us">
			<div class="section">
				<div class="container">
					<div class="title" style="background-color: white;position: relative;">
						<h1>About Us</h1>
					</div>
					<div class="content">
						<div class="article " style="padding-left: 138px;padding-top: 40px;">
							<h3>
								Fast Food Restaurant
, Craig Stephen, opened the first ‘Fast Food Restaurant’ Restaurant in Assiut Governorate, on october 5, 2001. Today,
 there are 37 areas all through Arizona, California, Illinois, Louisiana, Nevada, Oregon, Tennessee, and Washington.
‘Organization Name’ Restaurants are well known with a substantial gathering of people, including families,
 kids, seniors, and business experts. Our benevolent condition is perfect for praising unique events, facilitating a business lunch, or assembling for a flavorful dinner with loved ones.

							</h3>
							<p id="more" style="display:none">Open day by day for lunch and dinner,’ Company Name’ offers a choice of naturally arranged things utilizing just the best fixings accessible. Top picks incorporate Certified Angus Beef®, crisp fish, rotisserie chicken, and infant back pork ribs.
								New prepared pot pie, strength plates of mixed greens, wood-let go pizzas, pasta, sandwiches, burgers, and more.’Company Name’s heated merchandise and treats, including our Six-Layer Chocolate Motherlode Cake, Scratch Carrot Cake, and delectably rich cream cheddar pies are prevalent top choices with our visitors.
								
							</p>
							<div class="Button">
								<a id="ReadMore">Read More </a>
							</div>
						</div>
					</div>
					<div class="image-section">
						<a href="#"><img src="assets/images/about-img.png" width="30%" style="/* margin-left: 150px; */margin-right: 150px;width: 311px;" alt=""></a>
					</div>
				</div>
			</div>
		</section>
		<section id="gallary">
			<div class="container">
				<div class="title" style="background-color: white;position: relative;">
					<h1>Gallary</h1>
				</div>
				<div class="wrapper">
					<img src="assets/images/1.jpg" alt="">
					<img src="assets/images/2.jpg" alt="">
					<img src="assets/images/3.jpg" alt="">
					<img src="assets/images/4.jpg" alt="">
					<img src="assets/images/5.jpg" alt="">
					<img src="assets/images/6.jpg" alt="">
					<img src="assets/images/7.jpg" alt="">
					<img src="assets/images/8.jpg" alt="">
					<img src="assets/images/9.jpg" alt="">
					<img src="assets/images/10.jpg" alt="">
				</div>
			</div>
		</section>
		<section id="reviews">
			<div class="container" style="
				background: #f1f1f1;
				padding-top: 50px;
				margin-top: 25px;
				">
				<div class="title" style="background-color: #f1f1f1;position: relative;padding-top: 11px;">
					<h1>Reviews</h1>
				</div>
				<div class="testimonials">
					<div class="testimonial-inner">
						<div class="row">
							<div class="col">
								<div class="testimonial">
									<img src="assets/images/Review/1.jpg" alt="">
									<div class="name">John</div>
									<div class="stars">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
									<p>It’s a great experience. The ambiance is very welcoming and charming. Amazing wines, food and service.
										 Staff are extremely knowledgeable and make great recommendations.</p>
								</div>
							</div>
							<div class="col">
								<div class="testimonial">
									<img src="assets/images/Review/2.jpg" alt="">
									<div class="name">Bilie</div>
									<div class="stars">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="far fa-star"></i>
									</div>
									<p>Delicious food, waiters are very attentive, and super nice atmosphere. Plus it’s all at an affordable price.
										Can totally recommend it and will definitely come back again.</p>
								</div>
							</div>
							<div class="col">
								<div class="testimonial">
									<img src="assets/images/Review/3.jpg" alt="">
									<div class="name">Smith</div>
									<div class="stars">
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
										<i class="fas fa-star"></i>
									</div>
									<p>This spot gives extraordinary service and yummy meals. One of my favourite restaurants around town. The meals served rapidly and the rates were reasonable. 
										Highly recommended.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section id="contact us">
		
			<div class="container-1">
				<form method="post" action="about.php" >
					<div class="form-group">
						<label for="name">Name:</label>
						<input type="text" id="name" name="name" >
					</div>
					<div class="form-group">
						<label for="email">Email:</label>
						<input type="email" id="email" name="email" >
					</div>
					<div class="form-group">
						<label for="message">Message:</label>
						<textarea id="message" name="message" rows="5" ></textarea>
					</div>
					<input type="submit" name="submit" value="submit">
				</form>
				<div class="contact-info">
					<h2>Contact Information</h2>
					<p><strong>Address:</strong> Assiut yousry Ragheb st</p>
					<p><strong>Phone:</strong> (+02) 01048399817 </p>
					<p><strong>Email:</strong> info@myrestaurant.com</p>
					<p><strong>the time now is:</strong> <?php echo"[ ".date("h:i:sa")."]";?></p>
				</div>
			</div>
		</section>
		<footer>
			<div class="footer-content">
				<h3>Fast Food Restaurant</h3>
				<p>Since our modest beginnings in 2001 with a little space in Assiut Governorate, ‘Fast Food Restaurant’ 
					‘s development has been enlivened with the energy to cook and serve solid, Indian-roused takeout food..
				</p>
				<ul class="socials">
					<li><a target="_blank" href="https://www.facebook.com/profile.php?id=100005517794675&amp;mibextid=ZbWKwL"><i class="fa-brands fa-facebook"></i></a></li>
					<li><a target="_blank" href="https://twitter.com/Mahmoud07880670?t=RRZy5N196MF28Do4ycA-DQ&amp;s=09"><i class="fa-brands fa-twitter"></i></a></li>
					<li><a target="_blank" href="https://www.google.com"><i class="fa-brands fa-google-plus-g"></i></a></li>
					<li><a target="_blank" href="https://www.youtube.com"><i class="fa-brands fa-youtube"></i></a></li>
					<li><a target="_blank" href="https://www.linkedin.com/in/mahmoud-hamada-baa646221"><i class="fa-brands fa-linkedin"></i></a></li>
				</ul>
			</div>
			<div class="footer-bottom">
				<!-- php code show automatically update the copyright year on our website -->
				<p> © 2001-<?php echo date("Y ");?><a target="_blank" href="https://www.facebook.com/profile.php?id=100005517794675&amp;mibextid=ZbWKwL">Eng.Michael Ibrahim</a> </p>
			</div>
		</footer>
		
	</body>
</html>